// Simple “API” to load metadata.json
function fetchProducts() {
    return $.getJSON('metadata.json');
  }