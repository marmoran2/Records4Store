function fillHeroCarousel() {
  const heroInner = document.querySelector('#heroCarousel .carousel-inner');
  if (!heroInner) return;

  const items = Array.from({ length: 6 }, (_, i) => `
    <div class="carousel-item ${i === 0 ? 'active' : ''}">
      <img src="../assets/images/Hero Banners/Hero_Post_${i + 1}.webp" class="d-block w-100" alt="Hero ${i + 1}">
    </div>
  `).join('');

  heroInner.innerHTML = items;
}

function fillCarousel(id, items, perSlide = 3) {
  const container = document.querySelector(`#${id} .carousel-inner`);
  if (!container) return;

  container.innerHTML = '';

  for (let i = 0; i < items.length; i += perSlide) {
    const chunk = items.slice(i, i + perSlide);
    const slide = document.createElement('div');
    slide.className = `carousel-item ${i === 0 ? 'active' : ''} card-grid-item`;


    slide.innerHTML = `
      <div class="row row-cols-1 row-cols-md-${perSlide} g-4">
        ${chunk.map(product => `
          <div class="col">
            <div class="card h-100">
              <img src="${product.img}" class="card-img-top" alt="${product.title}">
              <div class="card-body text-center">
                <h5 class="card-title">${product.title}</h5>
                <a href="${product.link}" class="btn btn-sm btn-custom">View</a>
              </div>
            </div>
          </div>
        `).join('')}
      </div>
    `;

    container.appendChild(slide);
  }
}

async function loadProductMetadata() {
  const res = await fetch('../assets/json/metadata.json');
  if (!res.ok) throw new Error(`Failed to fetch metadata.json`);
  return await res.json();
}

function transformMetaToCarouselItem(product) {
  return {
    img: `../assets/images/album_artworks/artwork-${product.index}-300.webp`,
    title: product.trackName,
    link: `product.html?index=${product.index}" data-transition="product"`
  };
}

async function loadCarouselSection(id, rangeStart, rangeEnd) {
  try {
    const metadata = await loadProductMetadata();
    const items = metadata.slice(rangeStart, rangeEnd).map(transformMetaToCarouselItem);
    fillCarousel(id, items);
  } catch (err) {
    console.error(`Error loading carousel "${id}":`, err);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  fillHeroCarousel();
  loadCarouselSection('featuredCarousel', 0, 12);
  loadCarouselSection('upcomingCarousel', 12, 24);

  if (typeof setupPageTransitions === 'function') {
    setupPageTransitions();
  }
});
